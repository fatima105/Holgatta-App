<?php include 'include/header.php' ?>
      <!-- container -->
    </nav>
    <!-- /.Section Navbar -->
    <!-- Section Slider 1 -->
    <div id="section-slider2">
      <div class="swiper-container">
        <div class="swiper-wrapper d-none">
          <!-- Item -->
          <div class="swiper-slide">
            <div class="slider-content">
              <div class="container">
           
               
                <h3 class="text-success .fw-bold fs-5">
             
            
Terms And Conditions
</h3>
        <br>       
               
            </div> 
          </div>
                </div>
              </div>
            </div>
          </div>
          <!-- /.Item -->
        </div>
    </div>
  </div>
</div>

          <div class="container" >
            <h4 class=" ml-5  text-success"> Terms of Service</h4>
            <p class="ml-5 mr-5  d-flex flex-wrap justify-content-end">Welcome to the holgata (otherwise referred to as: “us”, “we”, and "holgata" in the following text). You (also referred to as the “customer” or “your” in the text) are currently reading the terms of services of our application/website that is aimed to provide an interesting experience of social networking. We provide services related to building a network and gaining followers for your holgata accounts. Here are some terms of service that you must agree on to get our services at our pleasant accord as customers and service providers. The terms are bound to legal constraints, so we suggest you to read them carefully befoe switching to the application.
            <h4 class=" ml-5  text-success"> Acceptance of terms of services</h4>
              <p class="ml-5">   We use Your Personal data to provide and improve the Service. By using the Service, You agree to the collection and use of information in accordance with this Privacy Policy.
            </p>
           <h4 class=" ml-5 text-success"> Our access to your account:</h4>
           <p class="ml-5 mr-5 ">You can read our Privacy policies to get an insight into the right of holgata to access the customer’s information directly and through third parties. holgata aims to increase your following of holgata, so it is mandatory to link your holgata account to your holgata profile. In this way, we get access to your profile and extract your technical and behavioral activities to suggest people that can be suitable for your profile. We reserve the right to disable your account anytime in case of any violation to the terms of services or privacy policies.  </p>
            <h4 class=" ml-5 display-6 text-success">    What type of information is collected </h4>
            <p class="ml-5 mr-5 ">  holgata gets access to your public information on your third-part profiles, as well as the country, gender, age, and social media preferences. The details are necessary to provide you with a group of followers who will watch your holgata content. With time, the technical and behavioral information provided by you is analyzed to maintain your group of followers that would help you increase your views as well.
            </p>
            <h4 class=" ml-5 display-6 text-success"> Your access to our services </h4>
            <p class="ml-5 mr-5 ">holgata reserves the right to review your activity and hold you accountable for any activity that comes in the domain of breaching terms of services or Privacy Policy. We suggest you do not agree and get access to the platform if you are able or legally competent to understand these terms. You are not allowed to interfere with the technical and logical operations of the application or website. The platform reserves the right to unlink your profile from holgata' or delete your profile, followed by a legal lawsuit in case of any cyberbullying, theft of intellectual property, or company property damage.  </p>
            <h4 class=" ml-5 display-6 text-success">  Changes in terms of service </h4>
            <p class="ml-5 mr-5 "> holgata may update the terms of services over time based on customer feedback, global reach, and legal interventions related to social norms. Every time we update our terms of services, we will notify you via email; if you have subscribed to receive newsletters and update notifications through email. Moreover, it will also be highlighted on this page with the title Last Updated, followed by the date of posting new terms of services. We intend to make the date of effect of the new privacy policies clear and the end of the previous one. If there is a change for a limited time we will also define the duration. Your acceptance to the new terms of services will be assessed by the continued use of the application. In any way you do not agree to the updated privacy policies, you must stop using the application or accessing your profile after writing us about the point of your concern at https://holgata.com/tos/ or email us at feedback@holgata.com.
            </p>
            <h4 class=" ml-5 display-6 text-success"> Indemnity </h4> 
            <p class="ml-5 mr-5 "> By accepting our terms of services, you agree to defend, harmlessly hold, and indemnify the holgata platform and its associated authorities, including the parent company, subsidiaries, and offices. You may or may not be limited to liabilities, costs of attorney fees in case of legal discourse due to breach of terms of services or privacy policy.   </p>
            <h4 class=" ml-5 display-6 text-success">  Intellectual property rights </h4> 
            <p class="ml-5 mr-5 ">  holgata is a suggestive networking platform that helps connect people on other social media platforms. We do not intend to gather, exploit, or investigate your intellectual properties. We do not own, review or grant access to any kind of content uploaded on the holgata'. Moreover, we do not allow you to publish any intellectual content intended or not for copyright infringement using the name, watermark, or logo of holgata.
            </p>
            <h4 class=" ml-5 display-6 text-success"> Warranties are excluded</h4> 
            <p class="ml-5 mr-5 ">  Nothing in these terms is out of the legal bounds of customer service or to which the customer cannot contractually agree. We guarantee you timely, safe, and uninterrupted services. Defects in operation can be a technical glitch that will be resolved as soon as it is identified. The software updates will be under the defined privacy policies and terms of services. We can remove, or edit some or all parts of the platform at any time without prior notice because of the business operations.
            </p>
            <h4 class=" ml-5 display-6 text-success"> Limiting the liabilities </h4>
            <p class="ml-5 mr-5 "> holgata is a networking site that gives free access to its customers to interact with other people. So, we do not hold any position in the dispute that arises between two parties using the platform unless it holds a legal position and is asked by the court.
            </p>
            <h4 class=" ml-5 mr-5  display-6 text-success"> Complaints related to our terms of service </h4>
         <p class="ml-5 mr-5 ">  If you happen to see any breach in terms of services, including the misinformation or unauthorized access to your personal information, you can contact us at https://holgata.com/tos/ or email us at feedback@holgata.com. We will help resolve the matter for your better experience. We have clearly stated our customer-service provider relationship, and what both parties are expecting from each other, so there would never in an intentional breach to privacy or user’s experience.. Moreover, if you have any complaints related to the terms of service and customer care management of our company, you can write us at https://holgata.com/tos/ or email us at feedback@holgata.com. </p>
        </p>
           <h4 class="mr-5  ml-5 text-success">  Contact Us
        
         <p class="justify-content-end"> If you have any queries, suggestions, or requests related to our terms of service, you can contact us at https://holgata.com/tos/ or email us at feedback@holgata.com.
You can print or save a copy of our terms of services.</p>
           </h4>

            </p

>
         </div>
    <!-- Section Footer -->
  
    <!-- Section Footer -->
    <?php include('include/footer.php')

?> 
    <!-- /.Section Footer -->

    <!-- Javascript Files -->
    <script src="assets/js/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Swiper Slider -->
    <script src="assets/js/swiper.min.js"></script>
    <!-- OWL Carousel -->
    <script src="assets/js/owl.carousel.min.js"></script>
    <!-- Waypoint -->
    <script src="assets/js/jquery.waypoints.min.js"></script>
    <!-- Easy Waypoint -->
    <script src="assets/js/easy-waypoint-animate.js"></script>
    <!-- Scripts -->
    <script src="assets/js/scripts.js"></script>
    <!-- Carousel Features 1 -->
    <script src="assets/js/carousel-features1.js"></script>
    <!-- Carousel App Screen 1 -->
    <script src="assets/js/carousel-appscreen1.js"></script>
    <!-- Carousel Testimonial 1 -->
    <script src="assets/js/carousel-testimonial1.js"></script>
  </body>

  <!-- Mirrored from puriwp.com/cocotemplates/html/appcraft/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 03 Aug 2022 15:30:15 GMT -->
</html>