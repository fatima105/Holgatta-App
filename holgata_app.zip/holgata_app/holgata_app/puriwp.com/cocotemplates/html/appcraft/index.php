<?php include 'include/header.php' ?>
      <!-- container -->
  
    <!-- /.Section Navbar -->
    <!-- Section Slider 1 -->
    <div id="section-slider1">
      <div class="swiper-container">
        <div class="swiper-wrapper d-none">
          <!-- Item -->
          <div class="swiper-slide">
            <div class="slider-content">
              <div class="container">
                <div class="row">
                  <div class="left col-12 col-sm-12 col-md-7">
                    <h1
                      class="ez-animate text-dark"
                      data-animation="fadeInLeft"
                    >
                      Holgata is Providing Best Animal Services.
                    </h1>
                    <p class="ez-animate text-dark" data-animation="fadeInLeft">
                      Download our Application to avail Offers
                    </p>
                    <ul>
                      <li>
                        <a href="#"
                          ><img
                            class="img-fluid ez-animate"
                            src="assets/images/img-appstore.png"
                            alt="Appcraft"
                            data-animation="fadeInUp"
                        /></a>
                      </li>
                      <li>
                        <a href="#"
                          ><img
                            class="img-fluid ez-animate"
                            src="assets/images/img-googleplay.png"
                            alt="Appcraft"
                            data-animation="fadeInUp"
                        /></a>
                      </li>
                    </ul>
                  </div>
                  <div
                    class="right ez-animate col-12 col-sm-12 col-md-5"
                    data-animation="fadeInRight"
                  >
                    <img
                      class="img-fluid"
                      src="assets/images/image-11.png"
                      alt="Appcraft"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- /.Item -->
        </div>
      </div>
    </div>
    <!-- /.Section Slider 1 -->
    <!-- Section Clients 1 -->

    <!-- /.Section Clients 1 -->
    <!-- Section Features 1 -->
    <div id="section-features1">
      <div class="container">
        <div class="row">
          <div class="left">
            <h6 class="clscheme">Check our Services</h6>
            <h2>The only app you need for your Animals Protection</h2>
            <ul>
              <li><i class="fa fa-long-arrow-left clscheme"></i></li>
              <li><i class="fa fa-long-arrow-right clscheme"></i></li>
            </ul>
          </div>
          <div class="right">
            <div class="swiper-container features1">
              <div class="swiper-wrapper">
                <!-- Item -->
                <div class="swiper-slide">
                  <div class="item">
                    <img src="assets/images/img-icon3.png" alt="Appcraft" />
                    <h3>Animal Food</h3>
                    <p>
                      Holgata is providing Best Quality food & Accessories for
                      your Pets.
                    </p>
                  </div>
                </div>
                <!-- /.Item -->
                <!-- Item -->
                <div class="swiper-slide">
                  <div class="item">
                    <img src="assets/images/img-icon1.png" alt="Appcraft" />
                    <h3>Book Appointment</h3>
                    <p>
                      Book Appointment for your Animals with the Best Doctors
                    </p>
                  </div>
                </div>
                <!-- /.Item -->
                <div class="swiper-slide">
                  <div class="item">
                    <img src="assets/images/img-icon2.png" alt="Appcraft" />
                    <h3>Animal Accessories</h3>
                    <p>
                      Holgata is providing Best Quality Accessories for your
                      Pets.
                    </p>
                  </div>
                </div>
                <!-- /.Item -->
                <!-- Item -->
                <!-- /.Item -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- /.Section Features 1 -->
    <!-- Features Wrap -->
    <div class="features-wrap">
      <!-- Section Features 2 -->
      <div id=features>
        <div class="container">
          <div class="row">
            <div class="left col-sm-12 col-md-6">
              <div class="img-container">
                <img
                  class="circleicon1 ez-animate"
                  src="assets/images/img-circleicon1.png"
                  alt="Appcraft"
                  data-animation="fadeInUp"
                />
                <img
                  class="img-fluid ez-animate"
                  src="assets/images/Doctor.png"
                  alt="Appcraft"
                  data-animation="fadeInLeft"
                />
              </div>
            </div>
            <div class="right my-auto col-sm-12 col-md-6">
              <h6 class="clscheme">
                Set Appointments for your Animals with Best Veterinarians
              </h6>
              <br />

              <h4>
                We Provide Different types of Services, Animal Food,Animal
                Accessories & we have best Veterinarians.
              </h4>
              <br />
              <a href="#" class="btn-2 shadow1 style3 bg-success"
                >GET STARTED NOW</a
              >
            </div>
          </div>
        </div>
      </div>
      <!-- /.Section Features 2 -->
      <!-- Section Features 2 -->
      <div class="section-features2">
        <div class="container">
          <div class="row">
            <div class="right my-auto col-sm-12 col-md-6">
              <h6 class="clscheme">
                You Can Select Best Veterinarian of your own Choice.
              </h6>
              <h2></h2>
              <p>
                We Provide Services 24/7 , you can make your order at any time.
                We will Response to your order.
              </p>
              <a href="#" class="btn-2 shadow1 style3 bg-success"
                >GET STARTED NOW</a
              >
            </div>
            <div class="left col-sm-12 col-md-6">
              <div class="img-container">
                <img
                  class="circleicon1 ez-animate"
                  src="assets/images/img-circleicon2.png"
                  alt="Appcraft"
                  data-animation="fadeInUp"
                />
                <img
                  class="img-fluid ez-animate"
                  src="assets/images/Dashboard.png"
                  alt="Appcraft"
                  data-animation="fadeInRight"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- /.Section Features 2 -->
    </div>
    <!-- /.Features Wrap -->
    <!-- Section APP Screen 1 -->
    <div id="section-appscreen1">
      <div class="container">
        <div class="row">
          <div class="title1 col-12">
            <h6 class="clscheme">APPLICATION SCREENS</h6>
            <h2 class="text-success">How Holgata looks like</h2>
          </div>
        </div>
      </div>
      <div class="container appscreen1">
        <div class="row">
          <div class="owl-carousel owl-theme">
            <!-- Item -->
            <div class="item">
              <img
                class="img-fluid"
                src="assets/images/IMG.png"
                alt="Appcraft"
              />
            </div>
            <!-- /.Item -->
            <!-- Item -->
            <div class="item">
              <img
                class="img-fluid"
                src="assets/images/IMG1.png"
                alt="Appcraft"
              />
            </div>
            <!-- /.Item -->
            <!-- Item -->
            <div class="item">
              <img
                class="img-fluid"
                src="assets/images/IMG2.png"
                alt="Appcraft"
              />
            </div>
            <!-- /.Item -->
            <!-- Item -->
            <div class="item">
              <img
                class="img-fluid"
                src="assets/images/IMG3.png"
                alt="Appcraft"
              />
            </div>
            <!-- /.Item -->
            <!-- Item -->
            <div class="item">
              <img
                class="img-fluid"
                src="assets/images/IMG4.png"
                alt="Appcraft"
              />
            </div>
            <!-- /.Item -->
            <!-- Item -->
          
          
            <!-- /.Item -->
            <!-- Item -->
            <div class="item">
              <img
                class="img-fluid"
                src="assets/images/IMG6.png"
                alt="Appcraft"
              />
            </div>
            <!-- /.Item -->
            <!-- Item -->
            <div class="item">
              <img
                class="img-fluid"
                src="assets/images/IMG7.png"
                alt="Appcraft"
              />
            </div>
            <!-- /.Item -->
            <!-- Item -->
            <div class="item">
              <img
                class="img-fluid"
                src="assets/images/IMG8.png"
                alt="Appcraft"
              />
            </div>
            <!-- /.Item -->
            <!-- Item -->

            <!-- /.Item -->
          </div>
          <!-- Add Pagination -->
          <div class="swiper-pagination"></div>
        </div>
      </div>
    </div>
    <!-- /.Section APP Sreen 1 -->
    <!-- Section Contacts 1 -->
    <div id="section-contact1">
      <div class="container">
        <div class="row">
          <div
            class="left ez-animate col-12 col-md-7"
            data-animation="fadeInLeft"
          >
            <form action="#">
              <div class="row">
                <div class="form-group col-sm-12 col-md-12 col-lg-12">
                  <input
                    type="text"
                    class="form-control"
                    name="name"
                    placeholder="Your name"
                    required=""
                  />
                </div>
                <div class="form-group col-sm-12 col-md-12 col-lg-12">
                  <input
                    type="email"
                    class="form-control"
                    name="email"
                    placeholder="Email address"
                    required=""
                  />
                </div>
                <div class="form-group col-12">
                  <textarea
                    class="form-control"
                    name="message"
                    placeholder="Write message here"
                    required=""
                  ></textarea>
                </div>
              </div>
              <div class="row">
                <div class="form-group col-md-12">
                  <button type="submit" class="shadow1 style3 bg-success">
                    SEND
                  </button>
                </div>
              </div>
            </form>
          </div>
          <div
            class="right ez-animate col-12 col-md-5"
            data-animation="fadeInRight"
          >
            <h3>Have any Queries?</h3>
            <ul>
              <li>Call us for imiditate support</li>
              <li>
                <a class="text-success" href="tel:+000 000 00 000"
                  >+000 000 00 000</a
                >
              </li>
            </ul>
            <ul>
              <li>Send us email for any kind of inquiry</li>
              <li>
                <a class="text-success" href="info@holgata.com"
                  >info@holgata.com</a
                >
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <!-- /.Section Pricingn 1 -->
    <!-- Section Testimonial 1 -->
    <!-- <div id="section-testimonial1">
      <div class="container">
        <div class="row">
          <div class="title1 col-12">
            <h6 class="clscheme">USER REVIEWS</h6>
            <h2>What People say About Holgata</h2>
          </div>
        </div>
      </div>
      <div class="container testimonial1">
        <img
          class="img-fluid bg-testimonial"
          src="assets/images/BG-testimonial1.jpg"
          alt="Appcraft"
        />
        <div class="row">
          <div class="owl-carousel owl-theme">
            
             <div class="item">
              <img src="assets/images/img-testimonial1.png" alt="Appcraft" />
              <h3>Arya Stark</h3>
              <h4>Client</h4>
              <ul>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
              </ul>
              <p>
                As part of the classes I teach, I task my students with
                preparing a lot of presentations. To save time & reduce boredom,
                I occasionally have only a pick who presents the good work!
              </p>
            </div>
           - /.Item -->
            <!-- Item -->
            <!-- <div class="item">
              <img src="assets/images/img-testimonial2.png" alt="Appcraft" />
              <h3>Arya Stark</h3>
              <h4>Client</h4>
              <ul>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
              </ul>
              <p>
                As part of the classes I teach, I task my students with
                preparing a lot of presentations. To save time & reduce boredom,
                I occasionally have only a pick who presents the good work!
              </p>
            </div>
            -
            <div class="item">
              <img src="assets/images/img-testimonial3.png" alt="Appcraft" />
              <h3>Arya Stark</h3>
              <h4>Client</h4>
              <ul>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
              </ul>
              <p>
                As part of the classes I teach, I task my students with
                preparing a lot of presentations. To save time & reduce boredom,
                I occasionally have only a pick who presents the good work!
              </p>
            </div>
       
            <div class="item">
              <img src="assets/images/img-testimonial1.png" alt="Appcraft" />
              <h3>Arya Stark</h3>
              <h4>Client</h4>
              <ul>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
              </ul>
              <p>
                As part of the classes I teach, I task my students with
                preparing a lot of presentations. To save time & reduce boredom,
                I occasionally have only a pick who presents the good work!
              </p>
            </div>
          =
            <div class="item">
              <img src="assets/images/img-testimonial2.png" alt="Appcraft" />
              <h3>Arya Stark</h3>
              <h4>Client</h4>
              <ul>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
                <li><i class="fa fa-star"></i></li>
              </ul>
              <p>
                As part of the classes I teach, I task my students with
                preparing a lot of presentations. To save time & reduce boredom,
                I occasionally have only a pick who presents the good work!
              </p>
            </div>
          
          </div>
        </div>
      </div>
    </div>  -->

    <!-- /.Section Subscribe 1 -->
    <!-- Section Download 1 -->
    <div id="section-download1">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <h1 class="text-success">Download Now</h1>
            <p class="text-success">and avail our amazing services</p>
            <ul>
              <li>
                <a href="#">
                  <img
                    class="img-fluid ez-animate"
                    src="assets/images/img-appstore.png"
                    alt="Appcraft"
                    data-animation="fadeInUp"
                  />
                </a>
              </li>
              <li>
                <a href="#">
                  <img
                    class="img-fluid ez-animate"
                    src="assets/images/img-googleplay.png"
                    alt="Appcraft"
                    data-animation="fadeInUp"
                  />
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
 <!-- Section Footer -->
 <?php include('include/footer.php')

?>    <!-- Javascript Files -->
    <script src="assets/js/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Swiper Slider -->
    <script src="assets/js/swiper.min.js"></script>
    <!-- OWL Carousel -->
    <script src="assets/js/owl.carousel.min.js"></script>
    <!-- Waypoint -->
    <script src="assets/js/jquery.waypoints.min.js"></script>
    <!-- Easy Waypoint -->
    <script src="assets/js/easy-waypoint-animate.js"></script>
    <!-- Scripts -->
    <script src="assets/js/scripts.js"></script>
    <!-- Carousel Features 1 -->
    <script src="assets/js/carousel-features1.js"></script>
    <!-- Carousel App Screen 1 -->
    <script src="assets/js/carousel-appscreen1.js"></script>
    <!-- Carousel Testimonial 1 -->
    <script src="assets/js/carousel-testimonial1.js"></script>
  </body>

  <!-- Mirrored from puriwp.com/cocotemplates/html/appcraft/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 03 Aug 2022 15:30:15 GMT -->
</html>