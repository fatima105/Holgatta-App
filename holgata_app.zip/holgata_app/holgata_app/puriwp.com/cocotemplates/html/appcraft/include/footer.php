<div id="section-footer">
      <div class="container">
        <div class="footer-widget">
          <div class="row">
            <div class="left col-md-6">
              <a href="index-2.html"
                ><img src="assets/images/logo.png" alt="Appcraft"
              /></a>
            </div>
            <div class="right col-md-6">
              
              <div class="social-links">
                <a href="#"
                  ><i class="fa fa-google-plus fa-lg" style="color: black"></i
                ></a>
                <a href="#"
                  ><i class="fa fa-twitter fa-lg" style="color: black"></i
                ></a>
                <a href="#"
                  ><i class="fa fa-instagram fa-lg" style="color: black"></i
                ></a>
                <a href="#"
                  ><i class="fa fa-behance fa-lg" style="color: black"></i
                ></a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="footer-copyright container-fluid">
        <div class="col-12">
        <a href="privacypolicy.php">Privacy Policy</a> <br>
          <a href="terms.php">Terms & Condition</a>
        <p class="text-dark"> <?php
             $year = date("Y");
              echo $year; ?> Copyrights
                  
              <a href="#"
                >Holgata</a
              >
            </p>
 
        </div>
      </div>
    </div>
    <!-- /.Section Footer -->