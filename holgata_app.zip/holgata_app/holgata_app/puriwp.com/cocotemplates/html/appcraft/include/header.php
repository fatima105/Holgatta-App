<!DOCTYPE html>
<html lang="en">
  <!-- Mirrored from puriwp.com/cocotemplates/html/appcraft/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 03 Aug 2022 15:30:15 GMT -->
  <head>
    <!-- Uniocde -->
    <meta charset="utf-8" />
    <!--[if IE]>
      <meta http-equiv="X-UA Compatible" content="IE=edge" />
    <![endif]-->
    <!-- First Mobile Meta -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- Pgae Description -->
    <meta name="description" content="Appcraft portfolio Template" />
    <!-- Page Kewords -->
    <meta name="keywords" content="Appcraft" />
    <!-- Site Author -->
    <meta name="author" content="Appcraft" />
    <!-- Title -->
    <title>Holgata</title>
    <!-- Favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.png" />
    <!-- Bootstrap 4 -->
    <link
      rel="stylesheet"
      href="assets/css/bootstrap.min.css"
      type="text/css"
    />
    <!-- Swiper Slider -->
    <link rel="stylesheet" href="assets/css/swiper.min.css" type="text/css" />
    <!-- Fonts -->
    <link
      rel="stylesheet"
      href="assets/fonts/fontawesome/font-awesome.min.css"
    />
    <!-- OWL Carousel -->
    <link
      rel="stylesheet"
      href="assets/css/owl.carousel.min.css"
      type="text/css"
    />
    <link
      rel="stylesheet"
      href="assets/css/owl.theme.default.min.css"
      type="text/css"
    />
    <!-- CSS Animate -->
    <link rel="stylesheet" href="assets/css/animate.min.css" type="text/css" />
    <!-- Style -->
    <link rel="stylesheet" href="assets/css/style.css" type="text/css" />
  </head>
  <body>
    <!-- /.Color Switcher -->
    <!-- Section Preloader -->
    <div id="section-preloader">
      <div class="boxes">
        <div class="box">
          <div></div>
          <div></div>
          <div></div>
          <div></div>
        </div>
        <div class="box">
          <div></div>
          <div></div>
          <div></div>
          <div></div>
        </div>
        <div class="box">
          <div></div>
          <div></div>
          <div></div>
          <div></div>
        </div>
        <div class="box">
          <div></div>
          <div></div>
          <div></div>
          <div></div>
        </div>
      </div>
      <p>LOADING . . .</p>
    </div>
    <!-- /.Section Preloader -->
    <!-- Section Navbar -->
    <nav class="navbar-1 navbar navbar-expand-lg">
      <div class="container navbar-container">
        <a class="navbar-brand" href="index-2.html"
          ><img
            src="assets/images/Group.png"
            style="width: 150px; margin-top: 13px; height:auto;"
            alt="Appcraft"
        /></a>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a
                href="index.php"
                class="nav-link scroll-down text-dark"
                >Home</a
              >
            </li>

            <li class="nav-item text-dark">
              <a
                href="index.php#section-features1 "
                class="nav-link scroll-down text-dark"
                >Services</a
              >
            </li>

            <li class="nav-item">
              <a
                href="index.php#features"
                class="nav-link scroll-down text-dark"
                >Features</a
              >
            </li>

            <li class="nav-item">
              <a href="index.php#section-contact1" class="nav-link scroll-down text-dark"
                >Contact Us</a
              >
            </li>
          </ul>
        </div>
      </div>
      </nav>